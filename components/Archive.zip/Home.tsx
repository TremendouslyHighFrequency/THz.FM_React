import React, { useState } from 'react';
import HomeFeature from './HomeFeature';

const Home = () => {

  return (
    <div className="m-18">
  <HomeFeature />
    </div>
  );
};

export default Home;

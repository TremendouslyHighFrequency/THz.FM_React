// Venues.jsx
import React from 'react';
import { MintForm } from './MintForm';

const Workspace = () => {
  return (
    <div className="content">
      <MintForm />
    </div>
  );
};

export default Workspace;


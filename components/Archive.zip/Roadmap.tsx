import React from 'react';

const Roadmap = () => {
  return (
    <div className="content">
      This is the Roadmap page.
    </div>
  );
};

export default Roadmap;


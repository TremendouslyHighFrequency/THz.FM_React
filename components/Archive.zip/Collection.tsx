// Venues.jsx
import React from 'react';

const Collection = () => {
  return (
    <div className="content">
      This is the Collection page.
    </div>
  );
};

export default Collection;


import { Card, Title, Text, Grid } from "@tremor/react";

export default function Example() {
  return (
    <main>

      {/* Main section */}
      <Card className="mt-6">
        <div className="h-96" />
      </Card>

    </main>
  );
}
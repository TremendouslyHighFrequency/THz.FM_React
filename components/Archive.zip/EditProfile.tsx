import React from 'react';

const EditProfile = () => (
  <iframe className="form-frame"
    src="https://thz.fm/me/edit-profile"
    width="100%"
  />
);

export default EditProfile;
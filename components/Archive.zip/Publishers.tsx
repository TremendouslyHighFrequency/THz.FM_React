// Publishers.jsx
import React from 'react';

const Publishers = () => {
  return (
    <div className="content">
      This is the Publishers page.
    </div>
  );
};

export default Publishers;


// Venues.jsx
import React from 'react';

const About = () => {
  return (
    <div className="content">
      This is the About page.
    </div>
  );
};

export default About;


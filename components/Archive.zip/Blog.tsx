import React from 'react';

const Blog = () => (
  <iframe className="form-frame"
    src="https://thz.fm/blog"
    width="100%"
  />
);

export default Blog;
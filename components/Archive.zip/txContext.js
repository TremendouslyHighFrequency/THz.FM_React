// TxContext.js
import React from 'react';

export const TxContext = React.createContext();
